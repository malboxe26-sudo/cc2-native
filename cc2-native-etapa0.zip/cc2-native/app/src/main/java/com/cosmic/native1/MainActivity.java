package com.cosmic.native1;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

public class MainActivity extends Activity implements SurfaceHolder.Callback {
    static { System.loadLibrary("cc2native"); }
    private native String nativeStart(Surface s, int w, int h);
    private native void nativeStop();
    private native void nativeTouch(int kind, float a, float b);
    private native String nativeStatus();

    private TextView tv;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private ScaleGestureDetector scale;
    private float lx, ly;
    private boolean started = false;
    private String startError = "";

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (started) tv.setText(nativeStatus());
            handler.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout root = new FrameLayout(this);
        SurfaceView sv = new SurfaceView(this);
        sv.getHolder().addCallback(this);
        root.addView(sv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        tv = new TextView(this);
        tv.setTextColor(Color.rgb(220, 230, 236));
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextSize(11);
        tv.setPadding(24, 72, 24, 24);
        tv.setText("iniciando...");
        root.addView(tv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);
        scale = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                if (started) nativeTouch(1, d.getScaleFactor(), 0);
                return true;
            }
        });
    }

    @Override protected void onResume() { super.onResume(); handler.post(poll); }
    @Override protected void onPause() { super.onPause(); handler.removeCallbacks(poll); }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        scale.onTouchEvent(e);
        if (!started) return true;
        int act = e.getActionMasked();
        if (act == MotionEvent.ACTION_DOWN) { lx = e.getX(); ly = e.getY(); }
        else if (act == MotionEvent.ACTION_POINTER_UP) {
            int i = e.getActionIndex() == 0 ? 1 : 0;
            lx = e.getX(i); ly = e.getY(i);
        } else if (act == MotionEvent.ACTION_MOVE && e.getPointerCount() == 1 && !scale.isInProgress()) {
            nativeTouch(0, e.getX() - lx, e.getY() - ly);
            lx = e.getX(); ly = e.getY();
        }
        return true;
    }

    @Override public void surfaceCreated(SurfaceHolder h) {}

    @Override
    public void surfaceChanged(SurfaceHolder h, int format, int w, int hh) {
        startError = nativeStart(h.getSurface(), w, hh);
        started = startError.isEmpty();
        if (!started) tv.setText("Erro ao iniciar Vulkan:\n" + startError);
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder h) {
        started = false;
        nativeStop();
    }
}
