package com.cosmic.native1;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends Activity implements SurfaceHolder.Callback {
    static { System.loadLibrary("cc2native"); }
    private native String nativeStart(Surface s, int w, int h);
    private native void nativeStop();
    private native void nativeTouch(int kind, float a, float b);
    private native String nativeStatus();
    private native void nativeCmd(int kind);
    private native void nativeSet(int id, float v);

    private TextView tv;
    private Button runBtn, colorBtn;
    private LinearLayout sliders;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private ScaleGestureDetector scale;
    private float lx, ly;
    private boolean started = false, running = false;
    private int mode = 0;
    private final String[] modes = {"material", "calor", "corpo"};

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (started) tv.setText(nativeStatus());
            handler.postDelayed(this, 500);
        }
    };

    private Button button(String t, LinearLayout row) {
        Button b = new Button(this);
        b.setText(t);
        b.setTextSize(12);
        b.setAllCaps(false);
        row.addView(b, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return b;
    }

    private void addSlider(LinearLayout parent, final String name, final int min, int max, int init,
                           final float scale, final int id, final String fmt) {
        final TextView lab = new TextView(this);
        lab.setTextColor(Color.rgb(220, 230, 236));
        lab.setTextSize(12);
        lab.setText(name + ": " + String.format(Locale.US, fmt, init * scale));
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(init - min);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                lab.setText(name + ": " + String.format(Locale.US, fmt, (p + min) * scale));
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {
                if (!started) return;
                nativeSet(id, (s.getProgress() + min) * scale);
                nativeCmd(1);
                running = false;
                runBtn.setText("Iniciar");
            }
        });
        parent.addView(lab);
        parent.addView(sb);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout root = new FrameLayout(this);
        SurfaceView sv = new SurfaceView(this);
        sv.getHolder().addCallback(this);
        root.addView(sv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        tv = new TextView(this);
        tv.setTextColor(Color.rgb(220, 230, 236));
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextSize(11);
        tv.setPadding(24, 72, 24, 24);
        tv.setText("iniciando...");
        root.addView(tv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(Color.argb(200, 12, 18, 24));
        panel.setPadding(24, 16, 24, 24);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        runBtn = button("Iniciar", row);
        Button resetBtn = button("Reiniciar", row);
        colorBtn = button("Cor: material", row);
        Button panelBtn = button("Ajustes", row);
        panel.addView(row);

        sliders = new LinearLayout(this);
        sliders.setOrientation(LinearLayout.VERTICAL);
        addSlider(sliders, "Velocidade do impacto", 5, 50, 25, 0.1f, 0, "%.1f");
        addSlider(sliders, "Particulas", 10, 200, 50, 100f, 1, "%.0f");
        addSlider(sliders, "Raio do alvo", 6, 20, 10, 0.1f, 4, "%.1f");
        addSlider(sliders, "Raio do impactor", 2, 12, 6, 0.1f, 2, "%.1f");
        addSlider(sliders, "Deslocamento lateral", 0, 22, 10, 0.05f, 3, "%.2f");
        sliders.setVisibility(View.GONE);
        panel.addView(sliders);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.BOTTOM;
        root.addView(panel, lp);
        setContentView(root);

        runBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (!started) return;
                nativeCmd(0);
                running = !running;
                runBtn.setText(running ? "Pausar" : "Iniciar");
            }
        });
        resetBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (!started) return;
                nativeCmd(1);
                running = false;
                runBtn.setText("Iniciar");
            }
        });
        colorBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (!started) return;
                nativeCmd(2);
                mode = (mode + 1) % 3;
                colorBtn.setText("Cor: " + modes[mode]);
            }
        });
        panelBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                sliders.setVisibility(sliders.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            }
        });

        scale = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                if (started) nativeTouch(1, d.getScaleFactor(), 0);
                return true;
            }
        });
    }

    @Override protected void onResume() { super.onResume(); handler.post(poll); }
    @Override protected void onPause() { super.onPause(); handler.removeCallbacks(poll); }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        scale.onTouchEvent(e);
        if (!started) return true;
        int act = e.getActionMasked();
        if (act == MotionEvent.ACTION_DOWN) { lx = e.getX(); ly = e.getY(); }
        else if (act == MotionEvent.ACTION_POINTER_UP) {
            int i = e.getActionIndex() == 0 ? 1 : 0;
            lx = e.getX(i); ly = e.getY(i);
        } else if (act == MotionEvent.ACTION_MOVE && e.getPointerCount() == 1 && !scale.isInProgress()) {
            nativeTouch(0, e.getX() - lx, e.getY() - ly);
            lx = e.getX(); ly = e.getY();
        }
        return true;
    }

    @Override public void surfaceCreated(SurfaceHolder h) {}

    @Override
    public void surfaceChanged(SurfaceHolder h, int format, int w, int hh) {
        String err = nativeStart(h.getSurface(), w, hh);
        started = err.isEmpty();
        running = false;
        runBtn.setText("Iniciar");
        if (!started) tv.setText("Erro ao iniciar Vulkan:\n" + err);
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder h) {
        started = false;
        nativeStop();
    }
}
