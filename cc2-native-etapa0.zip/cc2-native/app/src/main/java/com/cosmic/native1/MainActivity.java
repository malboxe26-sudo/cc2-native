package com.cosmic.native1;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    static { System.loadLibrary("vkinfo"); }
    private native String vulkanInfo();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        TextView t = new TextView(this);
        t.setText(vulkanInfo());
        t.setTextSize(13);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextColor(Color.rgb(220, 230, 236));
        t.setPadding(32, 96, 32, 48);
        t.setTextIsSelectable(true);
        ScrollView s = new ScrollView(this);
        s.setBackgroundColor(Color.rgb(12, 18, 24));
        s.addView(t);
        setContentView(s);
    }
}
