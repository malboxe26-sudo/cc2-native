// CC2 Nativo - Etapa 1: Vulkan desenhando uma nuvem de particulas (planeta com nucleo)
#include <jni.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <android/log.h>
#include <vulkan/vulkan.h>
#include <vulkan/vulkan_android.h>
#include <vector>
#include <string>
#include <thread>
#include <atomic>
#include <mutex>
#include <chrono>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <cstdint>
#include <algorithm>

#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "cc2", __VA_ARGS__)

alignas(4) static const unsigned char kVertSpv[] = {
#include "vert.inc"
};
alignas(4) static const unsigned char kFragSpv[] = {
#include "frag.inc"
};

struct Particle { float x, y, z, type; };
struct PC { float vp[16]; float ps; float pad[3]; };

static ANativeWindow* g_win = nullptr;
static int g_w = 0, g_h = 0;
static VkInstance g_inst = VK_NULL_HANDLE;
static VkSurfaceKHR g_surf = VK_NULL_HANDLE;
static VkPhysicalDevice g_pd = VK_NULL_HANDLE;
static VkDevice g_dev = VK_NULL_HANDLE;
static VkQueue g_q = VK_NULL_HANDLE;
static uint32_t g_qf = 0;
static VkSwapchainKHR g_sc = VK_NULL_HANDLE;
static VkFormat g_fmt = VK_FORMAT_UNDEFINED;
static VkFormat g_dfmt = VK_FORMAT_D32_SFLOAT;
static VkExtent2D g_ext{};
static std::vector<VkImage> g_imgs;
static std::vector<VkImageView> g_views;
static std::vector<VkFramebuffer> g_fbs;
static std::vector<VkSemaphore> g_semDone;
static VkImage g_dImg = VK_NULL_HANDLE;
static VkDeviceMemory g_dMem = VK_NULL_HANDLE;
static VkImageView g_dView = VK_NULL_HANDLE;
static VkRenderPass g_rp = VK_NULL_HANDLE;
static VkPipelineLayout g_pl = VK_NULL_HANDLE;
static VkPipeline g_pipe = VK_NULL_HANDLE;
static VkBuffer g_vb = VK_NULL_HANDLE;
static VkDeviceMemory g_vbm = VK_NULL_HANDLE;
static uint32_t g_n = 0;
static VkCommandPool g_pool = VK_NULL_HANDLE;
static VkCommandBuffer g_cmd[2];
static VkSemaphore g_semAcq[2] = {VK_NULL_HANDLE, VK_NULL_HANDLE};
static VkFence g_fence[2] = {VK_NULL_HANDLE, VK_NULL_HANDLE};
static std::string g_gpu, g_err;

static std::atomic<bool> g_run{false};
static std::thread g_th;
static std::mutex g_mx;
static std::string g_status;
static float g_yaw = 0.5f, g_pitch = 0.35f, g_dist = 75.f;
static bool g_auto = true;

static bool fail(const char* what, VkResult r) {
    g_err = std::string(what) + " -> erro " + std::to_string((int)r);
    LOG("%s", g_err.c_str());
    return false;
}
#define VK(x) do { VkResult _r = (x); if (_r != VK_SUCCESS) return fail(#x, _r); } while (0)

static uint32_t findMem(uint32_t bits, VkMemoryPropertyFlags want) {
    VkPhysicalDeviceMemoryProperties mp;
    vkGetPhysicalDeviceMemoryProperties(g_pd, &mp);
    for (uint32_t i = 0; i < mp.memoryTypeCount; i++)
        if ((bits & (1u << i)) && (mp.memoryTypes[i].propertyFlags & want) == want) return i;
    return UINT32_MAX;
}

// ---------- matematica (matrizes column-major) ----------
static void mul(const float* a, const float* b, float* o) {
    float t[16];
    for (int c = 0; c < 4; c++)
        for (int r = 0; r < 4; r++) {
            float s = 0;
            for (int k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k];
            t[c * 4 + r] = s;
        }
    memcpy(o, t, sizeof(t));
}
static void lookAt(const float* e, const float* c, float* m) {
    float f[3] = {c[0] - e[0], c[1] - e[1], c[2] - e[2]};
    float fl = std::sqrt(f[0] * f[0] + f[1] * f[1] + f[2] * f[2]);
    for (float& v : f) v /= fl;
    float s[3] = {f[1] * 0 - f[2] * 1, f[2] * 0 - f[0] * 0, f[0] * 1 - f[1] * 0}; // f x up(0,1,0)
    float sl = std::sqrt(s[0] * s[0] + s[1] * s[1] + s[2] * s[2]);
    for (float& v : s) v /= sl;
    float u[3] = {s[1] * f[2] - s[2] * f[1], s[2] * f[0] - s[0] * f[2], s[0] * f[1] - s[1] * f[0]};
    memset(m, 0, 16 * sizeof(float));
    m[0] = s[0]; m[1] = u[0]; m[2] = -f[0];
    m[4] = s[1]; m[5] = u[1]; m[6] = -f[1];
    m[8] = s[2]; m[9] = u[2]; m[10] = -f[2];
    m[12] = -(s[0] * e[0] + s[1] * e[1] + s[2] * e[2]);
    m[13] = -(u[0] * e[0] + u[1] * e[1] + u[2] * e[2]);
    m[14] = f[0] * e[0] + f[1] * e[1] + f[2] * e[2];
    m[15] = 1;
}
static void perspective(float fovy, float aspect, float zn, float zf, float* m) {
    float f = 1.f / std::tan(fovy * 0.5f);
    memset(m, 0, 16 * sizeof(float));
    m[0] = f / aspect;
    m[5] = -f; // Vulkan: Y para baixo
    m[10] = zf / (zn - zf);
    m[11] = -1;
    m[14] = zn * zf / (zn - zf);
}

// ---------- swapchain ----------
static void destroySwapchain() {
    if (!g_dev) return;
    for (auto f : g_fbs) vkDestroyFramebuffer(g_dev, f, nullptr);
    for (auto v : g_views) vkDestroyImageView(g_dev, v, nullptr);
    for (auto s : g_semDone) vkDestroySemaphore(g_dev, s, nullptr);
    g_fbs.clear(); g_views.clear(); g_semDone.clear(); g_imgs.clear();
    if (g_dView) vkDestroyImageView(g_dev, g_dView, nullptr);
    if (g_dImg) vkDestroyImage(g_dev, g_dImg, nullptr);
    if (g_dMem) vkFreeMemory(g_dev, g_dMem, nullptr);
    g_dView = VK_NULL_HANDLE; g_dImg = VK_NULL_HANDLE; g_dMem = VK_NULL_HANDLE;
    if (g_sc) vkDestroySwapchainKHR(g_dev, g_sc, nullptr);
    g_sc = VK_NULL_HANDLE;
}

static void pickDepthFormat() {
    VkFormatProperties fp;
    vkGetPhysicalDeviceFormatProperties(g_pd, VK_FORMAT_D32_SFLOAT, &fp);
    g_dfmt = (fp.optimalTilingFeatures & VK_FORMAT_FEATURE_DEPTH_STENCIL_ATTACHMENT_BIT)
                 ? VK_FORMAT_D32_SFLOAT : VK_FORMAT_D16_UNORM;
}

static bool createRenderPass() {
    VkAttachmentDescription at[2]{};
    at[0].format = g_fmt; at[0].samples = VK_SAMPLE_COUNT_1_BIT;
    at[0].loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR; at[0].storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    at[0].stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE; at[0].stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    at[0].initialLayout = VK_IMAGE_LAYOUT_UNDEFINED; at[0].finalLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
    at[1].format = g_dfmt; at[1].samples = VK_SAMPLE_COUNT_1_BIT;
    at[1].loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR; at[1].storeOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    at[1].stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE; at[1].stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    at[1].initialLayout = VK_IMAGE_LAYOUT_UNDEFINED; at[1].finalLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;
    VkAttachmentReference cref{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
    VkAttachmentReference dref{1, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL};
    VkSubpassDescription sp{};
    sp.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
    sp.colorAttachmentCount = 1; sp.pColorAttachments = &cref; sp.pDepthStencilAttachment = &dref;
    VkSubpassDependency dep{};
    dep.srcSubpass = VK_SUBPASS_EXTERNAL; dep.dstSubpass = 0;
    dep.srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT;
    dep.dstStageMask = dep.srcStageMask;
    dep.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
    VkRenderPassCreateInfo ri{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};
    ri.attachmentCount = 2; ri.pAttachments = at; ri.subpassCount = 1; ri.pSubpasses = &sp;
    ri.dependencyCount = 1; ri.pDependencies = &dep;
    VK(vkCreateRenderPass(g_dev, &ri, nullptr, &g_rp));
    return true;
}

static bool createSwapchain() {
    VkSurfaceCapabilitiesKHR caps;
    VK(vkGetPhysicalDeviceSurfaceCapabilitiesKHR(g_pd, g_surf, &caps));
    uint32_t fc = 0;
    vkGetPhysicalDeviceSurfaceFormatsKHR(g_pd, g_surf, &fc, nullptr);
    std::vector<VkSurfaceFormatKHR> fs(fc);
    vkGetPhysicalDeviceSurfaceFormatsKHR(g_pd, g_surf, &fc, fs.data());
    if (fc == 0) { g_err = "nenhum formato de superficie"; return false; }
    VkSurfaceFormatKHR sf = fs[0];
    for (auto& f : fs)
        if (f.format == VK_FORMAT_R8G8B8A8_UNORM || f.format == VK_FORMAT_B8G8R8A8_UNORM) { sf = f; break; }
    g_fmt = sf.format;
    g_ext = caps.currentExtent;
    if (g_ext.width == 0xFFFFFFFFu) { g_ext.width = (uint32_t)g_w; g_ext.height = (uint32_t)g_h; }
    if (g_ext.width == 0 || g_ext.height == 0) { g_err = "superficie com tamanho zero"; return false; }

    uint32_t cnt = caps.minImageCount + 1;
    if (caps.maxImageCount > 0 && cnt > caps.maxImageCount) cnt = caps.maxImageCount;
    VkSwapchainCreateInfoKHR ci{VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR};
    ci.surface = g_surf; ci.minImageCount = cnt; ci.imageFormat = sf.format; ci.imageColorSpace = sf.colorSpace;
    ci.imageExtent = g_ext; ci.imageArrayLayers = 1; ci.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
    ci.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE;
    ci.preTransform = (caps.supportedTransforms & VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR)
                          ? VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR : caps.currentTransform;
    ci.compositeAlpha = (caps.supportedCompositeAlpha & VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR)
                            ? VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR : VK_COMPOSITE_ALPHA_INHERIT_BIT_KHR;
    ci.presentMode = VK_PRESENT_MODE_FIFO_KHR; ci.clipped = VK_TRUE;
    VK(vkCreateSwapchainKHR(g_dev, &ci, nullptr, &g_sc));

    uint32_t n = 0;
    vkGetSwapchainImagesKHR(g_dev, g_sc, &n, nullptr);
    g_imgs.resize(n);
    vkGetSwapchainImagesKHR(g_dev, g_sc, &n, g_imgs.data());

    // profundidade
    VkImageCreateInfo di{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
    di.imageType = VK_IMAGE_TYPE_2D; di.format = g_dfmt;
    di.extent = {g_ext.width, g_ext.height, 1}; di.mipLevels = 1; di.arrayLayers = 1;
    di.samples = VK_SAMPLE_COUNT_1_BIT; di.tiling = VK_IMAGE_TILING_OPTIMAL;
    di.usage = VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT; di.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    VK(vkCreateImage(g_dev, &di, nullptr, &g_dImg));
    VkMemoryRequirements mr;
    vkGetImageMemoryRequirements(g_dev, g_dImg, &mr);
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    ai.allocationSize = mr.size;
    ai.memoryTypeIndex = findMem(mr.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    if (ai.memoryTypeIndex == UINT32_MAX) { g_err = "sem memoria para profundidade"; return false; }
    VK(vkAllocateMemory(g_dev, &ai, nullptr, &g_dMem));
    VK(vkBindImageMemory(g_dev, g_dImg, g_dMem, 0));
    VkImageViewCreateInfo dv{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
    dv.image = g_dImg; dv.viewType = VK_IMAGE_VIEW_TYPE_2D; dv.format = g_dfmt;
    dv.subresourceRange = {VK_IMAGE_ASPECT_DEPTH_BIT, 0, 1, 0, 1};
    VK(vkCreateImageView(g_dev, &dv, nullptr, &g_dView));

    for (uint32_t i = 0; i < n; i++) {
        VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
        vi.image = g_imgs[i]; vi.viewType = VK_IMAGE_VIEW_TYPE_2D; vi.format = g_fmt;
        vi.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
        VkImageView v;
        VK(vkCreateImageView(g_dev, &vi, nullptr, &v));
        g_views.push_back(v);
        if (g_rp) {
            VkImageView atts[2] = {v, g_dView};
            VkFramebufferCreateInfo fi{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};
            fi.renderPass = g_rp; fi.attachmentCount = 2; fi.pAttachments = atts;
            fi.width = g_ext.width; fi.height = g_ext.height; fi.layers = 1;
            VkFramebuffer fb;
            VK(vkCreateFramebuffer(g_dev, &fi, nullptr, &fb));
            g_fbs.push_back(fb);
        }
        VkSemaphoreCreateInfo si{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
        VkSemaphore sm;
        VK(vkCreateSemaphore(g_dev, &si, nullptr, &sm));
        g_semDone.push_back(sm);
    }
    return true;
}

static bool makeFramebuffersLater() {
    // usado na primeira criacao: o render pass depende do formato da swapchain
    for (uint32_t i = 0; i < g_views.size(); i++) {
        VkImageView atts[2] = {g_views[i], g_dView};
        VkFramebufferCreateInfo fi{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};
        fi.renderPass = g_rp; fi.attachmentCount = 2; fi.pAttachments = atts;
        fi.width = g_ext.width; fi.height = g_ext.height; fi.layers = 1;
        VkFramebuffer fb;
        VK(vkCreateFramebuffer(g_dev, &fi, nullptr, &fb));
        g_fbs.push_back(fb);
    }
    return true;
}

static VkShaderModule makeModule(const unsigned char* code, size_t size) {
    VkShaderModuleCreateInfo mi{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
    mi.codeSize = size; mi.pCode = reinterpret_cast<const uint32_t*>(code);
    VkShaderModule m = VK_NULL_HANDLE;
    vkCreateShaderModule(g_dev, &mi, nullptr, &m);
    return m;
}

static bool createPipeline() {
    VkShaderModule vs = makeModule(kVertSpv, sizeof(kVertSpv));
    VkShaderModule fs = makeModule(kFragSpv, sizeof(kFragSpv));
    if (!vs || !fs) { g_err = "falha ao criar modulos de shader"; return false; }
    VkPipelineShaderStageCreateInfo st[2]{};
    st[0].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    st[0].stage = VK_SHADER_STAGE_VERTEX_BIT; st[0].module = vs; st[0].pName = "main";
    st[1].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    st[1].stage = VK_SHADER_STAGE_FRAGMENT_BIT; st[1].module = fs; st[1].pName = "main";
    VkVertexInputBindingDescription bd{0, sizeof(Particle), VK_VERTEX_INPUT_RATE_VERTEX};
    VkVertexInputAttributeDescription ad{0, 0, VK_FORMAT_R32G32B32A32_SFLOAT, 0};
    VkPipelineVertexInputStateCreateInfo vi{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};
    vi.vertexBindingDescriptionCount = 1; vi.pVertexBindingDescriptions = &bd;
    vi.vertexAttributeDescriptionCount = 1; vi.pVertexAttributeDescriptions = &ad;
    VkPipelineInputAssemblyStateCreateInfo ia{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO};
    ia.topology = VK_PRIMITIVE_TOPOLOGY_POINT_LIST;
    VkPipelineViewportStateCreateInfo vp{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO};
    vp.viewportCount = 1; vp.scissorCount = 1;
    VkPipelineRasterizationStateCreateInfo rs{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO};
    rs.polygonMode = VK_POLYGON_MODE_FILL; rs.cullMode = VK_CULL_MODE_NONE;
    rs.frontFace = VK_FRONT_FACE_COUNTER_CLOCKWISE; rs.lineWidth = 1.f;
    VkPipelineMultisampleStateCreateInfo ms{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO};
    ms.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;
    VkPipelineDepthStencilStateCreateInfo ds{VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO};
    ds.depthTestEnable = VK_TRUE; ds.depthWriteEnable = VK_TRUE; ds.depthCompareOp = VK_COMPARE_OP_LESS;
    VkPipelineColorBlendAttachmentState cba{};
    cba.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT | VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
    VkPipelineColorBlendStateCreateInfo cb{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO};
    cb.attachmentCount = 1; cb.pAttachments = &cba;
    VkDynamicState dyn[2] = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};
    VkPipelineDynamicStateCreateInfo dy{VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO};
    dy.dynamicStateCount = 2; dy.pDynamicStates = dyn;
    VkPushConstantRange pr{VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(PC)};
    VkPipelineLayoutCreateInfo li{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    li.pushConstantRangeCount = 1; li.pPushConstantRanges = &pr;
    VK(vkCreatePipelineLayout(g_dev, &li, nullptr, &g_pl));
    VkGraphicsPipelineCreateInfo gi{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO};
    gi.stageCount = 2; gi.pStages = st; gi.pVertexInputState = &vi; gi.pInputAssemblyState = &ia;
    gi.pViewportState = &vp; gi.pRasterizationState = &rs; gi.pMultisampleState = &ms;
    gi.pDepthStencilState = &ds; gi.pColorBlendState = &cb; gi.pDynamicState = &dy;
    gi.layout = g_pl; gi.renderPass = g_rp; gi.subpass = 0;
    VkResult r = vkCreateGraphicsPipelines(g_dev, VK_NULL_HANDLE, 1, &gi, nullptr, &g_pipe);
    vkDestroyShaderModule(g_dev, vs, nullptr);
    vkDestroyShaderModule(g_dev, fs, nullptr);
    if (r != VK_SUCCESS) return fail("vkCreateGraphicsPipelines", r);
    return true;
}

static bool createParticles() {
    std::vector<Particle> p;
    const int R = 16;
    for (int i = -R; i <= R; i++)
        for (int j = -R; j <= R; j++)
            for (int k = -R; k <= R; k++) {
                int r2 = i * i + j * j + k * k;
                if (r2 <= R * R) p.push_back({(float)i, (float)j, (float)k, r2 <= (int)(0.45f * R * 0.45f * R) ? 2.f : 0.f});
            }
    const int ri = 4; const float cx = -10, cy = R + 9, cz = 0;
    for (int i = -ri; i <= ri; i++)
        for (int j = -ri; j <= ri; j++)
            for (int k = -ri; k <= ri; k++)
                if (i * i + j * j + k * k <= ri * ri) p.push_back({cx + i, cy + j, cz + k, 1.f});
    g_n = (uint32_t)p.size();
    VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    bi.size = p.size() * sizeof(Particle); bi.usage = VK_BUFFER_USAGE_VERTEX_BUFFER_BIT;
    bi.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    VK(vkCreateBuffer(g_dev, &bi, nullptr, &g_vb));
    VkMemoryRequirements mr;
    vkGetBufferMemoryRequirements(g_dev, g_vb, &mr);
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    ai.allocationSize = mr.size;
    ai.memoryTypeIndex = findMem(mr.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    if (ai.memoryTypeIndex == UINT32_MAX) { g_err = "sem memoria visivel para o buffer"; return false; }
    VK(vkAllocateMemory(g_dev, &ai, nullptr, &g_vbm));
    VK(vkBindBufferMemory(g_dev, g_vb, g_vbm, 0));
    void* map = nullptr;
    VK(vkMapMemory(g_dev, g_vbm, 0, VK_WHOLE_SIZE, 0, &map));
    memcpy(map, p.data(), bi.size);
    vkUnmapMemory(g_dev, g_vbm);
    return true;
}

static void cleanup() {
    if (g_dev) {
        vkDeviceWaitIdle(g_dev);
        for (int i = 0; i < 2; i++) {
            if (g_fence[i]) vkDestroyFence(g_dev, g_fence[i], nullptr);
            if (g_semAcq[i]) vkDestroySemaphore(g_dev, g_semAcq[i], nullptr);
            g_fence[i] = VK_NULL_HANDLE; g_semAcq[i] = VK_NULL_HANDLE;
        }
        destroySwapchain();
        if (g_pool) vkDestroyCommandPool(g_dev, g_pool, nullptr);
        if (g_vb) vkDestroyBuffer(g_dev, g_vb, nullptr);
        if (g_vbm) vkFreeMemory(g_dev, g_vbm, nullptr);
        if (g_pipe) vkDestroyPipeline(g_dev, g_pipe, nullptr);
        if (g_pl) vkDestroyPipelineLayout(g_dev, g_pl, nullptr);
        if (g_rp) vkDestroyRenderPass(g_dev, g_rp, nullptr);
        vkDestroyDevice(g_dev, nullptr);
    }
    if (g_inst) {
        if (g_surf) vkDestroySurfaceKHR(g_inst, g_surf, nullptr);
        vkDestroyInstance(g_inst, nullptr);
    }
    g_pool = VK_NULL_HANDLE; g_vb = VK_NULL_HANDLE; g_vbm = VK_NULL_HANDLE; g_pipe = VK_NULL_HANDLE;
    g_pl = VK_NULL_HANDLE; g_rp = VK_NULL_HANDLE; g_dev = VK_NULL_HANDLE; g_surf = VK_NULL_HANDLE;
    g_inst = VK_NULL_HANDLE; g_pd = VK_NULL_HANDLE;
}

static bool initAll() {
    const char* iext[] = {VK_KHR_SURFACE_EXTENSION_NAME, VK_KHR_ANDROID_SURFACE_EXTENSION_NAME};
    VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    app.pApplicationName = "cc2"; app.apiVersion = VK_API_VERSION_1_1;
    VkInstanceCreateInfo ici{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ici.pApplicationInfo = &app; ici.enabledExtensionCount = 2; ici.ppEnabledExtensionNames = iext;
    VK(vkCreateInstance(&ici, nullptr, &g_inst));
    VkAndroidSurfaceCreateInfoKHR sci{VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR};
    sci.window = g_win;
    VK(vkCreateAndroidSurfaceKHR(g_inst, &sci, nullptr, &g_surf));

    uint32_t n = 0;
    vkEnumeratePhysicalDevices(g_inst, &n, nullptr);
    if (n == 0) { g_err = "nenhuma GPU Vulkan"; return false; }
    std::vector<VkPhysicalDevice> pds(n);
    vkEnumeratePhysicalDevices(g_inst, &n, pds.data());
    g_pd = pds[0];
    VkPhysicalDeviceProperties props;
    vkGetPhysicalDeviceProperties(g_pd, &props);
    g_gpu = props.deviceName;
    VkPhysicalDeviceFeatures feat;
    vkGetPhysicalDeviceFeatures(g_pd, &feat);
    if (!feat.largePoints) { g_err = "GPU sem suporte a pontos grandes (largePoints)"; return false; }

    uint32_t qn = 0;
    vkGetPhysicalDeviceQueueFamilyProperties(g_pd, &qn, nullptr);
    std::vector<VkQueueFamilyProperties> qs(qn);
    vkGetPhysicalDeviceQueueFamilyProperties(g_pd, &qn, qs.data());
    bool found = false;
    for (uint32_t i = 0; i < qn; i++) {
        VkBool32 sup = VK_FALSE;
        vkGetPhysicalDeviceSurfaceSupportKHR(g_pd, i, g_surf, &sup);
        if ((qs[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) && sup) { g_qf = i; found = true; break; }
    }
    if (!found) { g_err = "nenhuma fila de graficos com apresentacao"; return false; }

    float prio = 1.f;
    VkDeviceQueueCreateInfo qi{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
    qi.queueFamilyIndex = g_qf; qi.queueCount = 1; qi.pQueuePriorities = &prio;
    const char* dext[] = {VK_KHR_SWAPCHAIN_EXTENSION_NAME};
    VkPhysicalDeviceFeatures en{};
    en.largePoints = VK_TRUE;
    VkDeviceCreateInfo dci{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
    dci.queueCreateInfoCount = 1; dci.pQueueCreateInfos = &qi;
    dci.enabledExtensionCount = 1; dci.ppEnabledExtensionNames = dext; dci.pEnabledFeatures = &en;
    VK(vkCreateDevice(g_pd, &dci, nullptr, &g_dev));
    vkGetDeviceQueue(g_dev, g_qf, 0, &g_q);

    // 1) swapchain sem framebuffers (precisamos do formato para o render pass)
    pickDepthFormat();
    VkRenderPass saved = g_rp; g_rp = VK_NULL_HANDLE;
    if (!createSwapchain()) return false;
    g_rp = saved;
    if (!createRenderPass()) return false;
    if (!makeFramebuffersLater()) return false;
    if (!createPipeline()) return false;
    if (!createParticles()) return false;

    VkCommandPoolCreateInfo pi{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    pi.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT; pi.queueFamilyIndex = g_qf;
    VK(vkCreateCommandPool(g_dev, &pi, nullptr, &g_pool));
    VkCommandBufferAllocateInfo cai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    cai.commandPool = g_pool; cai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY; cai.commandBufferCount = 2;
    VK(vkAllocateCommandBuffers(g_dev, &cai, g_cmd));
    for (int i = 0; i < 2; i++) {
        VkSemaphoreCreateInfo si{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
        VK(vkCreateSemaphore(g_dev, &si, nullptr, &g_semAcq[i]));
        VkFenceCreateInfo fi{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
        fi.flags = VK_FENCE_CREATE_SIGNALED_BIT;
        VK(vkCreateFence(g_dev, &fi, nullptr, &g_fence[i]));
    }
    return true;
}

static bool recreateSwapchain() {
    vkDeviceWaitIdle(g_dev);
    destroySwapchain();
    if (!createSwapchain()) return false;
    return true;
}

static void record(int fr, uint32_t idx) {
    VkCommandBuffer c = g_cmd[fr];
    vkResetCommandBuffer(c, 0);
    VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    vkBeginCommandBuffer(c, &bi);
    VkClearValue cl[2];
    cl[0].color = {{0.047f, 0.07f, 0.09f, 1.f}};
    cl[1].depthStencil = {1.f, 0};
    VkRenderPassBeginInfo rb{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};
    rb.renderPass = g_rp; rb.framebuffer = g_fbs[idx];
    rb.renderArea.extent = g_ext; rb.clearValueCount = 2; rb.pClearValues = cl;
    vkCmdBeginRenderPass(c, &rb, VK_SUBPASS_CONTENTS_INLINE);
    vkCmdBindPipeline(c, VK_PIPELINE_BIND_POINT_GRAPHICS, g_pipe);
    VkViewport vp{0, 0, (float)g_ext.width, (float)g_ext.height, 0.f, 1.f};
    VkRect2D sc{{0, 0}, g_ext};
    vkCmdSetViewport(c, 0, 1, &vp);
    vkCmdSetScissor(c, 0, 1, &sc);

    float cp = std::cos(g_pitch);
    float eye[3] = {g_dist * cp * std::sin(g_yaw), 6.f + g_dist * std::sin(g_pitch), g_dist * cp * std::cos(g_yaw)};
    float ctr[3] = {0.f, 6.f, 0.f};
    float V[16], P[16];
    lookAt(eye, ctr, V);
    const float fov = 0.9f;
    perspective(fov, (float)g_ext.width / (float)g_ext.height, 1.f, 600.f, P);
    PC pc{};
    mul(P, V, pc.vp);
    float focal = (g_ext.height * 0.5f) / std::tan(fov * 0.5f);
    pc.ps = 1.05f * focal;
    vkCmdPushConstants(c, g_pl, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(PC), &pc);
    VkDeviceSize off = 0;
    vkCmdBindVertexBuffers(c, 0, 1, &g_vb, &off);
    vkCmdDraw(c, g_n, 1, 0, 0);
    vkCmdEndRenderPass(c);
    vkEndCommandBuffer(c);
}

static void setStatus(const std::string& s) {
    std::lock_guard<std::mutex> lk(g_mx);
    g_status = s;
}

static void loopFn() {
    int fr = 0, frames = 0;
    auto t0 = std::chrono::steady_clock::now();
    while (g_run) {
        vkWaitForFences(g_dev, 1, &g_fence[fr], VK_TRUE, UINT64_MAX);
        uint32_t idx = 0;
        VkResult r = vkAcquireNextImageKHR(g_dev, g_sc, UINT64_MAX, g_semAcq[fr], VK_NULL_HANDLE, &idx);
        if (r == VK_ERROR_OUT_OF_DATE_KHR) {
            if (!recreateSwapchain()) { setStatus("Erro: " + g_err); break; }
            continue;
        }
        if (r != VK_SUCCESS && r != VK_SUBOPTIMAL_KHR) { setStatus("Erro no acquire: " + std::to_string((int)r)); break; }
        vkResetFences(g_dev, 1, &g_fence[fr]);
        if (g_auto) g_yaw += 0.003f;
        record(fr, idx);
        VkPipelineStageFlags wait = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
        VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
        si.waitSemaphoreCount = 1; si.pWaitSemaphores = &g_semAcq[fr]; si.pWaitDstStageMask = &wait;
        si.commandBufferCount = 1; si.pCommandBuffers = &g_cmd[fr];
        si.signalSemaphoreCount = 1; si.pSignalSemaphores = &g_semDone[idx];
        r = vkQueueSubmit(g_q, 1, &si, g_fence[fr]);
        if (r != VK_SUCCESS) { setStatus("Erro no submit: " + std::to_string((int)r)); break; }
        VkPresentInfoKHR pi{VK_STRUCTURE_TYPE_PRESENT_INFO_KHR};
        pi.waitSemaphoreCount = 1; pi.pWaitSemaphores = &g_semDone[idx];
        pi.swapchainCount = 1; pi.pSwapchains = &g_sc; pi.pImageIndices = &idx;
        r = vkQueuePresentKHR(g_q, &pi);
        if (r == VK_ERROR_OUT_OF_DATE_KHR) {
            if (!recreateSwapchain()) { setStatus("Erro: " + g_err); break; }
        } else if (r != VK_SUCCESS && r != VK_SUBOPTIMAL_KHR) {
            setStatus("Erro no present: " + std::to_string((int)r)); break;
        }
        fr = (fr + 1) % 2;
        frames++;
        auto now = std::chrono::steady_clock::now();
        double dt = std::chrono::duration<double>(now - t0).count();
        if (dt >= 1.0) {
            char buf[256];
            snprintf(buf, sizeof(buf), "%.0f fps | %u particulas | %s | %ux%u\nArraste: girar | Pinca: zoom",
                     frames / dt, g_n, g_gpu.c_str(), g_ext.width, g_ext.height);
            setStatus(buf);
            frames = 0; t0 = now;
        }
    }
    vkDeviceWaitIdle(g_dev);
}

static void stopAll() {
    g_run = false;
    if (g_th.joinable()) g_th.join();
    cleanup();
    if (g_win) { ANativeWindow_release(g_win); g_win = nullptr; }
}

extern "C" {
JNIEXPORT jstring JNICALL Java_com_cosmic_native1_MainActivity_nativeStart(JNIEnv* env, jobject, jobject surface, jint w, jint h) {
    stopAll();
    g_win = ANativeWindow_fromSurface(env, surface);
    g_w = w; g_h = h; g_err.clear();
    if (!g_win) return env->NewStringUTF("ANativeWindow nulo");
    if (!initAll()) {
        std::string e = g_err;
        stopAll();
        return env->NewStringUTF(e.c_str());
    }
    setStatus("iniciando...");
    g_run = true;
    g_th = std::thread(loopFn);
    return env->NewStringUTF("");
}
JNIEXPORT void JNICALL Java_com_cosmic_native1_MainActivity_nativeStop(JNIEnv*, jobject) { stopAll(); }
JNIEXPORT void JNICALL Java_com_cosmic_native1_MainActivity_nativeTouch(JNIEnv*, jobject, jint kind, jfloat a, jfloat b) {
    g_auto = false;
    if (kind == 0) {
        g_yaw -= a * 0.006f;
        g_pitch = std::max(-1.4f, std::min(1.4f, g_pitch + b * 0.006f));
    } else {
        g_dist = std::max(15.f, std::min(250.f, g_dist / a));
    }
}
JNIEXPORT jstring JNICALL Java_com_cosmic_native1_MainActivity_nativeStatus(JNIEnv* env, jobject) {
    std::lock_guard<std::mutex> lk(g_mx);
    return env->NewStringUTF(g_status.c_str());
}
}
