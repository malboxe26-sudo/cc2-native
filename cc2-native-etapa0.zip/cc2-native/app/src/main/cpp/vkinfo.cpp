#include <jni.h>
#include <vulkan/vulkan.h>
#include <string>
#include <vector>

static std::string ver(uint32_t v) {
    return std::to_string(VK_VERSION_MAJOR(v)) + "." + std::to_string(VK_VERSION_MINOR(v)) + "." +
           std::to_string(VK_VERSION_PATCH(v));
}
static std::string mb(uint64_t b) { return std::to_string(b / (1024 * 1024)) + " MB"; }

extern "C" JNIEXPORT jstring JNICALL
Java_com_cosmic_native1_MainActivity_vulkanInfo(JNIEnv* env, jobject) {
    std::string o = "CC2 Nativo - Etapa 0\nDiagnostico Vulkan\n\n";

    VkApplicationInfo app{};
    app.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    app.pApplicationName = "cc2";
    app.apiVersion = VK_API_VERSION_1_1;
    VkInstanceCreateInfo ci{};
    ci.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    ci.pApplicationInfo = &app;

    VkInstance inst = VK_NULL_HANDLE;
    VkResult r = vkCreateInstance(&ci, nullptr, &inst);
    if (r != VK_SUCCESS) {
        o += "FALHA ao criar instancia Vulkan. Codigo: " + std::to_string((int)r) + "\n";
        return env->NewStringUTF(o.c_str());
    }

    uint32_t n = 0;
    vkEnumeratePhysicalDevices(inst, &n, nullptr);
    std::vector<VkPhysicalDevice> devs(n);
    vkEnumeratePhysicalDevices(inst, &n, devs.data());
    o += "Dispositivos Vulkan: " + std::to_string(n) + "\n\n";

    for (VkPhysicalDevice d : devs) {
        VkPhysicalDeviceProperties p;
        vkGetPhysicalDeviceProperties(d, &p);
        const VkPhysicalDeviceLimits& L = p.limits;
        o += "GPU: " + std::string(p.deviceName) + "\n";
        o += "Vulkan: " + ver(p.apiVersion) + "\n";
        o += "Driver: " + std::to_string(p.driverVersion) + "\n\n";

        o += "COMPUTE\n";
        o += "- invocacoes por grupo: " + std::to_string(L.maxComputeWorkGroupInvocations) + "\n";
        o += "- tamanho do grupo: " + std::to_string(L.maxComputeWorkGroupSize[0]) + " x " +
             std::to_string(L.maxComputeWorkGroupSize[1]) + " x " +
             std::to_string(L.maxComputeWorkGroupSize[2]) + "\n";
        o += "- memoria compartilhada: " + std::to_string(L.maxComputeSharedMemorySize) + " bytes\n";
        o += "- buffers de armazenamento por estagio: " +
             std::to_string(L.maxPerStageDescriptorStorageBuffers) + "\n";
        o += "- maior buffer de armazenamento: " + mb(L.maxStorageBufferRange) + "\n";

        if (p.apiVersion >= VK_API_VERSION_1_1) {
            VkPhysicalDeviceSubgroupProperties sg{};
            sg.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SUBGROUP_PROPERTIES;
            VkPhysicalDeviceProperties2 p2{};
            p2.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2;
            p2.pNext = &sg;
            vkGetPhysicalDeviceProperties2(d, &p2);
            o += "- tamanho do subgrupo: " + std::to_string(sg.subgroupSize) + "\n";
        }

        VkPhysicalDeviceFeatures f;
        vkGetPhysicalDeviceFeatures(d, &f);
        o += "- float64 em shader: " + std::string(f.shaderFloat64 ? "sim" : "nao") + "\n";
        o += "- int64 em shader: " + std::string(f.shaderInt64 ? "sim" : "nao") + "\n\n";

        uint32_t qn = 0;
        vkGetPhysicalDeviceQueueFamilyProperties(d, &qn, nullptr);
        std::vector<VkQueueFamilyProperties> qs(qn);
        vkGetPhysicalDeviceQueueFamilyProperties(d, &qn, qs.data());
        bool compute = false, both = false;
        for (auto& q : qs) {
            bool c = q.queueFlags & VK_QUEUE_COMPUTE_BIT, g = q.queueFlags & VK_QUEUE_GRAPHICS_BIT;
            compute |= c;
            both |= (c && g);
        }
        o += "FILAS\n- fila de compute: " + std::string(compute ? "sim" : "nao") +
             "\n- fila graficos+compute: " + std::string(both ? "sim" : "nao") + "\n\n";

        VkPhysicalDeviceMemoryProperties m;
        vkGetPhysicalDeviceMemoryProperties(d, &m);
        uint64_t local = 0;
        bool unified = false;
        for (uint32_t i = 0; i < m.memoryHeapCount; i++)
            if (m.memoryHeaps[i].flags & VK_MEMORY_HEAP_DEVICE_LOCAL_BIT) local += m.memoryHeaps[i].size;
        const VkMemoryPropertyFlags want = VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT |
                                           VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT |
                                           VK_MEMORY_PROPERTY_HOST_COHERENT_BIT;
        for (uint32_t i = 0; i < m.memoryTypeCount; i++)
            if ((m.memoryTypes[i].propertyFlags & want) == want) unified = true;
        o += "MEMORIA\n- local da GPU: " + mb(local) + "\n- memoria unificada: " +
             std::string(unified ? "sim" : "nao") + "\n\n";

        bool ok = compute && L.maxComputeWorkGroupInvocations >= 128;
        o += std::string("VEREDITO: ") +
             (ok ? "apto para SPH em GPU (compute)" : "compute limitado, vamos avaliar") + "\n";
        o += "----------------------------------------\n";
    }
    vkDestroyInstance(inst, nullptr);
    return env->NewStringUTF(o.c_str());
}
