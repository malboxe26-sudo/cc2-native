#version 450
layout(location = 0) in vec4 vA;
layout(location = 1) in vec4 vT;
layout(location = 0) out vec4 outCol;
layout(set = 0, binding = 0) uniform sampler2D uA1;
layout(set = 0, binding = 1) uniform sampler2D uA2;
layout(push_constant) uniform PC { mat4 vp; float ps; float mode; float peak; float p2; vec4 cr; vec4 cu; vec4 cb; } pc;

vec3 matCol(int m, float h) {
    if (m == 0) return mix(vec3(.42, .37, .31), vec3(.08, .22, .45), step(.55, h));
    if (m == 1) return vec3(.56, .58, .64) * (.8 + .4 * h);
    if (m == 2) return mix(vec3(.45, .17, .08), vec3(.8, .34, .1), h);
    if (m == 3) return vec3(.75, .88, .97);
    if (m == 4) return vec3(.04, .18, .45) * (.8 + .5 * h);
    if (m == 5) return mix(vec3(.85, .62, .38), vec3(.95, .88, .72), h);
    if (m == 6) return vec3(.1, .07, .06) * (.8 + .5 * h);
    return vec3(1., .8, .42);
}

vec3 atlas(int ti, vec2 uvc) {
    if (ti >= 10) {
        float idx = float(ti - 10);
        vec2 cell = vec2(mod(idx, 2.), floor(idx / 2.));
        return textureLod(uA2, (cell + uvc) * vec2(.5, .3333333), 0.).rgb;
    }
    float idx = float(ti);
    vec2 cell = vec2(mod(idx, 2.), floor(idx / 2.));
    return textureLod(uA1, (cell + uvc) * vec2(.5, .3333333), 0.).rgb;
}

void main() {
    vec2 c = gl_PointCoord * 2.0 - 1.0;
    float r2 = dot(c, c);
    if (r2 > 1.0) discard;
    float nz = sqrt(1.0 - r2);
    vec3 n = vec3(c.x, -c.y, nz);
    vec3 L = normalize(vec3(-.5, .6, .65));
    float t = vA.x;
    int mode = int(pc.mode + 0.5);
    int mt = int(vA.y + 0.5);
    bool textured = (mode == 0) && (vT.w > -.5);
    vec3 col;
    if (mode == 1) col = mix(vec3(.1, .15, .45), vec3(1., .45, .08), t) + vec3(t * .4);
    else if (mode == 2) col = (vA.z < .5) ? vec3(.3, .7, .9) : vec3(1., .55, .2);
    else col = matCol(mt, vA.w);
    if (textured) {
        vec3 nw = n.x * pc.cr.xyz + n.y * pc.cu.xyz + n.z * pc.cb.xyz;
        vec3 dd = normalize(vT.xyz + nw * .1);
        float u = atan(dd.z, dd.x) * .15915 + .5;
        float v = .5 - asin(clamp(dd.y, -1., 1.)) * .31831;
        col = atlas(int(vT.w + .5), vec2(clamp(u, .003, .997), clamp(v, .006, .994)));
    }
    float dif = max(dot(n, L), 0.) * .95 + .12;
    if (mt == 7 && mode != 1) dif = 1.15;
    float s = pow(max(dot(reflect(-L, n), vec3(0., 0., 1.)), 0.), 24.) * ((mt == 1) ? .5 : .12);
    col = col * dif + s;
    if (mt == 7 && mode == 0) t = 1.;
    vec3 lava = mix(vec3(.45, .02, 0.), vec3(.95, .22, .02), smoothstep(0., .45, t));
    lava = mix(lava, vec3(1., .4, .05), smoothstep(.7, 1., t)) * (1. + 2. * t);
    if (mode != 1 && mt != 7) col = mix(col, lava, smoothstep(.02, .25, t));
    outCol = vec4(col, 1.0);
}
