#version 450
layout(location = 0) in vec4 vA;
layout(location = 0) out vec4 outCol;
layout(push_constant) uniform PC { mat4 vp; float ps; float mode; float peak; float p2; } pc;
vec3 matCol(int m, float h) {
    if (m == 0) return mix(vec3(.42, .37, .31), vec3(.08, .22, .45), step(.55, h));
    if (m == 1) return vec3(.56, .58, .64) * (.8 + .4 * h);
    if (m == 2) return mix(vec3(.45, .17, .08), vec3(.8, .34, .1), h);
    if (m == 3) return vec3(.75, .88, .97);
    if (m == 4) return vec3(.04, .18, .45) * (.8 + .5 * h);
    if (m == 5) return mix(vec3(.85, .62, .38), vec3(.95, .88, .72), h);
    if (m == 6) return vec3(.1, .07, .06) * (.8 + .5 * h);
    return vec3(1., .8, .42);
}
void main() {
    vec2 c = gl_PointCoord * 2.0 - 1.0;
    float r2 = dot(c, c);
    if (r2 > 1.0) discard;
    float nz = sqrt(1.0 - r2);
    vec3 n = vec3(c.x, -c.y, nz);
    vec3 l = normalize(vec3(-0.4, 0.6, 0.7));
    float t = vA.x;
    int mode = int(pc.mode + 0.5);
    vec3 col;
    if (mode == 1) col = mix(vec3(.1, .15, .45), vec3(1., .45, .08), t) + vec3(t * .4);
    else if (mode == 2) col = (vA.z < .5) ? vec3(.3, .7, .9) : vec3(1., .55, .2);
    else col = matCol(int(vA.y + 0.5), vA.w);
    float d = max(dot(n, l), 0.0);
    float s = pow(max(dot(reflect(-l, n), vec3(0., 0., 1.)), 0.0), 20.0);
    col = col * (0.3 + 0.7 * d) + 0.12 * s;
    vec3 lava = mix(vec3(.45, .02, 0.), vec3(.95, .22, .02), smoothstep(0., .45, t));
    lava = mix(lava, vec3(1., .4, .05), smoothstep(.7, 1., t)) * (1. + 2. * t);
    if (mode != 1) col = mix(col, lava, smoothstep(.02, .25, t));
    outCol = vec4(col, 1.0);
}
