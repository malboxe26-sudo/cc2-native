#version 450
layout(location = 0) in vec3 vCol;
layout(location = 0) out vec4 outCol;
void main() {
    vec2 c = gl_PointCoord * 2.0 - 1.0;
    float r2 = dot(c, c);
    if (r2 > 1.0) discard;
    float nz = sqrt(1.0 - r2);
    vec3 n = vec3(c.x, -c.y, nz);
    vec3 l = normalize(vec3(-0.4, 0.6, 0.7));
    float d = max(dot(n, l), 0.0);
    float s = pow(max(dot(reflect(-l, n), vec3(0.0, 0.0, 1.0)), 0.0), 20.0);
    outCol = vec4(vCol * (0.35 + 0.65 * d) + 0.15 * s, 1.0);
}
