layout(push_constant) uniform CPB {
    uint n; float H; float H2; float W6; float GS; float K; float C; float DT; float EPS2; float cellMin; uint pad0; uint pad1;
} cp;
layout(std430, set = 0, binding = 0) buffer B0 { vec4 pos[]; };
layout(std430, set = 0, binding = 1) buffer B1 { vec4 vel[]; };
layout(std430, set = 0, binding = 2) buffer B2 { vec4 acc[]; };
layout(std430, set = 0, binding = 3) buffer B3 { vec4 grav[]; };
layout(std430, set = 0, binding = 4) buffer B4 { vec4 props[]; };
layout(std430, set = 0, binding = 5) buffer B5 { vec4 rhoP[]; };
layout(std430, set = 0, binding = 6) buffer B6 { int head[]; };
layout(std430, set = 0, binding = 7) buffer B7 { int nxt[]; };
layout(std430, set = 0, binding = 8) buffer B8 { uint bb[8]; vec4 gorg; ivec4 gdim; } meta;

const float KM[8]   = float[8](1., 1., 1., .8, .8, .4, 1., .6);
const float RHO0[8] = float[8](1., 1.8, 1.25, .9, 1., .35, 1.1, .6);

uint f2u(float f) { uint u = floatBitsToUint(f); return ((u & 0x80000000u) != 0u) ? ~u : (u | 0x80000000u); }
float u2f(uint u) { u = ((u & 0x80000000u) != 0u) ? (u & 0x7fffffffu) : ~u; return uintBitsToFloat(u); }
ivec3 cellOf(vec3 p) {
    ivec3 g = ivec3(floor((p - meta.gorg.xyz) / meta.gorg.w));
    return clamp(g, ivec3(0), meta.gdim.xyz - ivec3(1));
}
int cellId(ivec3 g) { return (g.z * meta.gdim.y + g.y) * meta.gdim.x + g.x; }
