#version 450
layout(location = 0) in vec4 inP;
layout(location = 1) in vec4 inQ;
layout(push_constant) uniform PC { mat4 vp; float ps; float mode; float peak; float p2; } pc;
layout(location = 0) out vec4 vA;
void main() {
    gl_Position = pc.vp * vec4(inP.xyz, 1.0);
    gl_PointSize = max(2.0, pc.ps / gl_Position.w);
    float h = fract(sin(float(gl_VertexIndex) * 12.9898) * 43758.5453);
    vA = vec4(clamp(inP.w / pc.peak, 0.0, 1.0), inQ.z, inQ.w, h);
}
