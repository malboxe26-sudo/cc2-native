#version 450
layout(location = 0) in vec4 inP;
layout(push_constant) uniform PC { mat4 vp; float ps; float p0; float p1; float p2; } pc;
layout(location = 0) out vec3 vCol;
void main() {
    gl_Position = pc.vp * vec4(inP.xyz, 1.0);
    gl_PointSize = max(2.0, pc.ps / gl_Position.w);
    vCol = inP.w > 1.5 ? vec3(0.88, 0.65, 0.27) : (inP.w > 0.5 ? vec3(0.31, 0.84, 0.78) : vec3(0.75, 0.55, 0.39));
}
